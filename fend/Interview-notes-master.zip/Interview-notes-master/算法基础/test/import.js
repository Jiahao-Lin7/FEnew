import { arg } from './export'
console.log(arg)