const arg = {
  data: 1
}
export {arg}