## 已收录：
- [x] 字节跳动
- [ ] ~~阿里巴巴 (禁)~~
- [ ] 腾讯


## easy：

53. [尝试使用分治法](https://leetcode-cn.com/problems/maximum-subarray/solution/zui-da-zi-xu-he-by-leetcode-solution/)

70. 爬楼梯-斐波那契数列
21、53、70、88、101、108、111、206、234、543！


## medium：
5、39*2、92、145、236、322、486、547、673、695

## hard：
10、25、51

高频:
堆/快速/归并排序