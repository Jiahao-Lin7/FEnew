export const ShapeFlags = {
  ELEMENT: 1, // 元素
  FUNCTION_COMPONENT: 1 << 1,
  STATEFUL_COMPONENT:1<<2, // 组件
  TEXT_CHILDREN:1<<3,
  ARRAY_CHILDREN:1<<4
}