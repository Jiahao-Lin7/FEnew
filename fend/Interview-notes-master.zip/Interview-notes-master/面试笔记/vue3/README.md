## vue3 源码实现

1、reactive 实现  
2、track依赖收集，trigger触发更新  
3、增加runtime-core和runtime-dom的相关代码  
4、节点初始化操作  
5、diff算法，根据key复用节点  
6、利用vue3中实现的 getSequence 方法进行一个优化。