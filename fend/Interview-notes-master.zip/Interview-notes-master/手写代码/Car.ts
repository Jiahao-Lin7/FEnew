export class Body {}
export class Chassis {}
export class Engine {
  start() {
    console.log('引擎发动了')
  }
}