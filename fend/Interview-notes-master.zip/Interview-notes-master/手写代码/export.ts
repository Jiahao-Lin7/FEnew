import { doThing, Options } from './new'
let foo: any;
let x = foo ?.bar.baz()